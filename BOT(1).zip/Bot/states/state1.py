from telebot.asyncio_handler_backends import State, StatesGroup

class STATE1_(StatesGroup):
    State1 = State()