from telebot.asyncio_handler_backends import State, StatesGroup

class STATE2_(StatesGroup):
    State1 = State()
    State2 = State()